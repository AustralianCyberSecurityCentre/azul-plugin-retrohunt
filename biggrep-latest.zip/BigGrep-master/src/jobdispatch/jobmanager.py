# jobdispatch
#
# @license:   GPL and Govt't Purpose, see LICENSE.txt for details
# @copyright: 2013-2017 by Carnegie Mellon University
# @author:    Matt Coates <mfcoates@cert.org>
class JobManager(object):
    #job_spec_key is the value of the key to use in the processor to retrieve jobs from this type of job management system
    job_spec_key=""
    def getJob(self,processor):
        pass
    def putJob(self,job):
        pass
